const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const {execFileSync} = require('node:child_process');
const cheerio = require('cheerio'), yaml = require('yaml');
const {loadPosts,render} = require('../lib/posts.cjs');
const baseline = require('./migration-baseline.json');
const read = p => fs.readFileSync(p,'utf8');
const build = () => execFileSync(process.execPath,['node_modules/@11ty/eleventy/cmd.cjs'],{stdio:'pipe'});
const cleanBuild = () => {execFileSync(process.execPath,['scripts/clean.cjs']);build();};
const norm = s => s.replace(/\s+/g,' ').trim();
function signature(html) {
  const $ = cheerio.load(html,null,false);
  function walk(nodes) { return nodes.flatMap(n => {
    if (n.type==='text') return norm(n.data) ? [{text:norm(n.data)}] : [];
    if (n.type!=='tag') return [];
    return [{tag:n.name,attrs:n.attribs,children:walk(n.children||[])}];
  }); }
  return walk($.root().contents().toArray());
}
function files(dir) {return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(path.join(dir,e.name)):[path.join(dir,e.name)]);}
test('production build and complete migration preserve content, semantics and functionality', () => {
  cleanBuild();
  for(const [slug,expected] of Object.entries(baseline.articles)) {
    const $ = cheerio.load(read(`_site/blog/${slug}/index.html`));
    assert.deepEqual(signature($('.article-copy').html()),signature(expected.body),slug);
    assert.equal($('h1').text(),expected.title);
    assert.equal($('.article-deck').text(),expected.excerpt);
    assert.equal($('title').text(),expected.seoTitle);
    assert.equal($('meta[name="description"]').attr('content'),expected.description);
    for(const [selector,key] of [['header','header'],['footer','footer'],['#chat','chat']]) assert.deepEqual(signature($(selector).toString()),signature(expected[key]));
    assert.deepEqual(signature($('.blog-lead-band').html()),signature(expected.cta));
    const schema=JSON.parse($('script[type="application/ld+json"]').text());
    assert.equal(schema.mainEntityOfPage,`https://vendigola.com/blog/${slug}/`);
    assert.equal(schema.datePublished,undefined);
    assert.equal(schema.dateModified,undefined);
    assert.equal($('h1').length,1);
    assert.equal($('meta[property="og:type"]').attr('content'),'article');
    assert.equal($('meta[name="twitter:card"]').length,1);
  }
  for(const [file,hash] of Object.entries(baseline.files)) {
    if(file==='netlify.toml'||file==='sitemap.xml'||file==='blog/index.html'||(/^blog\//.test(file)&&!file.startsWith('blog/article-template/'))) continue;
    const generated = `_site/${file}`;
    // The original readme is a source document, not a public asset.
    if(file==='readme.md') continue;
    assert.equal(crypto.createHash('sha256').update(fs.readFileSync(generated)).digest('hex'),hash,file);
  }
  const archive=cheerio.load(read('_site/blog/index.html'));
  assert.equal(archive('.blog-card').length,7);
  assert.deepEqual(archive('.blog-card').toArray().map(e=>archive(e).attr('href')),Object.keys(baseline.articles).map(s=>`/blog/${s}/`));
  assert.deepEqual(signature(archive('header').toString()),signature(Object.values(baseline.articles)[0].header));
  assert.deepEqual(signature(archive('.blog-sidebar').html()),signature(Object.values(baseline.articles)[0].cta));
  const xml=cheerio.load(read('_site/sitemap.xml'),{xml:true});const urls=xml('loc').toArray().map(e=>xml(e).text());
  assert.equal(urls.length,29);assert.equal(new Set(urls).size,urls.length);
  assert(!fs.existsSync('_site/content'));assert(!fs.existsSync('_site/.pages.yml'));assert(!fs.existsSync('_site/node_modules'));
});
test('all generated internal links, images and fragments resolve',()=>{
  for(const file of files('_site').filter(f=>f.endsWith('.html'))) {
    const $=cheerio.load(read(file));
    const base='https://vendigola.com/'+path.relative('_site',file).replace(/index\.html$/,'');
    for(const el of $('a[href],img[src],script[src],link[href]').toArray()) {
      const href=$(el).attr(el.name==='img'||el.name==='script'?'src':'href');
      const url=new URL(href,base);if(url.origin!=='https://vendigola.com') continue;
      let target=path.join('_site',decodeURIComponent(url.pathname));if(url.pathname.endsWith('/')) target=path.join(target,'index.html');
      assert(fs.existsSync(target),`${file}: missing ${href}`);
      if(url.hash&&target.endsWith('.html')) {
        const dest=cheerio.load(read(target));const id=decodeURIComponent(url.hash.slice(1));
        assert(dest('[id]').toArray().some(e=>dest(e).attr('id')===id),`${file}: missing fragment ${href}`);
      }
    }
  }
});
test('CMS schema includes all fields with markdown body and correct media URLs',()=>{
  const config=yaml.parse(read('.pages.yml'));
  assert.equal(config.media.input,'assets/blog');assert.equal(config.media.output,'/assets/blog');
  const fields=config.content[0].fields;
  assert.equal(fields.find(f=>f.name==='body').options.format,'markdown');
  for(const key of ['title','slug','excerpt','body','status']) assert(fields.find(f=>f.name===key).required);
  assert.equal(fields.length,19);
  for (const name of ['publishedDate','updatedDate']) {assert.equal(fields.find(f=>f.name===name).default,'');assert.equal(fields.find(f=>f.name===name).options.format,'yyyy-MM-dd');}
  assert.equal(fields.find(f=>f.name==='status').default,'draft');
});
test('create, edit, images, draft, publish, unpublish, slug and metadata validation',()=>{
  const fixture='content/posts/workflow-test.md';
  const d={title:'Workflow </script><script>alert(1)</script>',slug:'workflow-test',excerpt:'Original excerpt',status:'draft',publishedDate:'2026-11-16',updatedDate:'2026-11-16',featured:true,featuredImage:'/assets/schools-campus.jpg',featuredImageAlt:'School campus building',ogImage:'/assets/schools-campus.jpg'};
  const body='## Test section\n\nA complete paragraph with a [contact link](/contact/).\n\n![School grounds](/assets/schools-campus.jpg)';
  const save=(data=d,text=body)=>fs.writeFileSync(fixture,'---\n'+yaml.stringify(data)+'---\n\n'+text);
  try {
    save();cleanBuild();assert(!fs.existsSync('_site/blog/workflow-test'));assert(!read('_site/blog/index.html').includes('/blog/workflow-test/'));assert(!read('_site/sitemap.xml').includes('/blog/workflow-test/'));
    d.status='published';save();cleanBuild();
    assert(fs.existsSync('_site/blog/workflow-test/index.html'));
    let $=cheerio.load(read('_site/blog/workflow-test/index.html'));
    assert.equal($('h1').text(),d.title);assert.equal($('script').length,2);
    const archive=cheerio.load(read('_site/blog/index.html'));assert.equal(archive('.blog-card').first().attr('href'),'/blog/workflow-test/');assert.equal($('img[alt="School grounds"]').attr('loading'),'lazy');assert(Number($('img[alt="School grounds"]').attr('width'))>0);
    assert.equal($('img[alt="School campus building"]').attr('loading'),undefined);
    assert.equal(JSON.parse($('script[type="application/ld+json"]').text()).datePublished,d.publishedDate);
    assert(read('_site/sitemap.xml').includes('/blog/workflow-test/'));
    d.excerpt='Changed excerpt';d.title='Edited workflow';save();cleanBuild();
    assert(read('_site/blog/index.html').includes('Changed excerpt'));assert(read('_site/blog/workflow-test/index.html').includes('Edited workflow'));
    d.status='draft';save();cleanBuild();assert(!fs.existsSync('_site/blog/workflow-test'));assert(!read('_site/sitemap.xml').includes('/blog/workflow-test/'));
    save({...d,slug:Object.keys(baseline.articles)[0]});assert.throws(()=>loadPosts(),/Duplicate slug/);assert.throws(build);
    save({...d,slug:'../escape'});assert.throws(()=>loadPosts(),/Invalid or reserved slug/);
    save({...d,featuredImageAlt:''});assert.throws(()=>loadPosts(),/alt text/);
    save({...d,publishedDate:'2026-02-30'});assert.throws(()=>loadPosts(),/Invalid publication/);
    save({...d,canonical:'https://evil.example/'});assert.throws(()=>loadPosts(),/Canonical must/);
    save({...d,featuredImage:'/assets/missing.jpg'});assert.throws(()=>loadPosts(),/Missing image/);
    save({...d,title:''});assert.throws(()=>loadPosts(),/title is required/);
    save(d,'');assert.throws(()=>loadPosts(),/body is required/);
  } finally {fs.rmSync(fixture,{force:true});cleanBuild();}
});
test('unsafe authored HTML and links cannot become active markup',()=>{
  const $=cheerio.load(render('<script>alert(1)</script>\n\n<img src=x onerror=alert(1)>\n\n[bad](javascript:alert(1))'));
  assert.equal($('script,img,[onerror],a[href^="javascript:"]').length,0);
  assert.throws(()=>render('# Another H1'),/H2/);
  assert.throws(()=>render('![Bad](https://evil.example/a.png)'),/Invalid image path/);
});
