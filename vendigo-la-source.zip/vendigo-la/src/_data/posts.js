module.exports = () => require('../../lib/posts.cjs').loadPosts().filter(p => p.status === 'published');
