module.exports = function (config) {
  // Explicit public allowlist: never publish content, configuration, tests or credentials.
  const dirs = ['about','accessibility','assets','contact','cookies','faq','how-it-works','industries','privacy','service-areas','solutions','terms'];
  for (const p of [...dirs, 'index.html','site.css','blog-media.css','site.js','favicon.svg','robots.txt','_headers','blog/article-template']) config.addPassthroughCopy({[p]: p});
  config.addWatchTarget('content/posts/');
  config.addWatchTarget('assets/blog/');
  config.addFilter('number', n => String(n).padStart(2,'0'));
  config.addFilter('jsonld', value => JSON.stringify(value).replace(/</g,'\\u003c'));
  config.addFilter('image', (src, alt, lazy = false) => require('./lib/posts.cjs').image(src, alt, lazy));
  config.addFilter('absolute', src => new URL(src, 'https://vendigola.com').href);
  config.addNunjucksGlobal('productionDomain', 'https://vendigola.com');
  return { dir: {input:'src', includes:'_includes', data:'_data', output:'_site'}, templateFormats:['njk'], htmlTemplateEngine:'njk' };
};
