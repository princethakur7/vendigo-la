const fs = require('node:fs');
fs.rmSync('_site', { recursive: true, force: true });
