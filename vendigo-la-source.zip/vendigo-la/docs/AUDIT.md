# Audit and change manifest

Audit date: 16 November 2026. Input: `deploy-6aef74949b2004de0fd02a3b.zip` supplied by the owner. The current task workspace initially contained no development source, repository or package manifest. Other unrelated projects were not used. The ZIP was treated as website data; the separately supplied task brief defined the implementation request.

## Original architecture

- 30 HTML pages: 21 static non-blog pages, blog archive, seven articles and an article-template example.
- Plain HTML/CSS/JavaScript. No generator, CMS, database, authentication or package manifest.
- `netlify.toml` published `.` without a build command.
- Shared CSS and JS are root files. Original navigation, footer, cookie handling, chatbot, WhatsApp links and Formspree submission logic are preserved.
- Inquiry forms target `https://formspree.io/f/xoejbkbg`.
- Seven complete articles share the same shell and CTA. Bodies contain paragraphs, H2/H3, links, lists and a comparison table, all representable in Markdown with GFM tables.
- The original sitemap has 36 entries, representing 29 distinct URLs. The seven article URLs are duplicated. The example template is intentionally absent from the original sitemap and retains its original indexing directives.
- Original titles/descriptions and canonical domain are retained. No article publication/update dates were present. Original authors were not attributed to named individuals; the organization is the documented rendering default.
- External fetches did not establish the live production domain or Netlify configuration. No account access was supplied. `https://vendigola.com` is retained as the source's intended canonical domain, pending owner verification.

## Architecture decisions

Root business HTML stays where it was. Only explicit public directories/files are copied into `_site`. Eleventy reads templates under `src`, and the global data loader reads YAML-frontmatter Markdown from `content/posts`. Only validated Published posts are passed to article pagination, cards and sitemap generation. Clean builds remove the entire old output first. No original hardcoded article files remain to bypass filtering.

Article Markdown is never interpreted as a template. Raw HTML is disabled, output is sanitized, image URLs are constrained to existing local raster assets, alt text is mandatory and YAML is parsed without executable frontmatter engines. The comparison table uses ordinary GFM Markdown, not a custom unsafe rendering shortcut. The old public article-template URL is preserved as a static example with its original robots metadata.

## Existing files changed/replaced

- `netlify.toml`: build command, `_site` output, Node 22.
- `blog/index.html`: replaced by `src/blog/archive.njk`.
- `blog/<each-of-seven-existing-slugs>/index.html`: replaced by Markdown content and `src/blog/article.njk`, producing the identical original public paths.
- `sitemap.xml`: replaced by `src/sitemap.njk` and the original non-article URL list.
- `readme.md`: retained as `docs/original-readme.md`; new README provides current operation instructions.

## New files

- `.pages.yml`, `.gitignore`, `.nvmrc`.
- `package.json`, `package-lock.json`.
- `eleventy.config.js`, `blog-media.css` (blog-scoped responsive media rules).
- `content/posts/*.md` (seven posts).
- `assets/blog/.gitkeep` (upload directory).
- `lib/posts.cjs`, `lib/legacy-order.json`.
- `src/blog/article.njk`, `src/blog/archive.njk`, `src/sitemap.njk`.
- `src/_includes/head.njk`, `header.njk`, `footer.njk`, `inquiry.njk`.
- `src/_data/posts.js`, `src/_data/staticUrls.json`.
- `scripts/clean.cjs`, `scripts/serve.cjs`.
- `tests/cms.test.cjs`, `tests/migration-baseline.json`.
- `.github/workflows/validate.yml`, `README.md`, `docs/AUDIT.md`, `docs/TESTING.md`.

Every other original public file is byte-identical in the generated output. SHA-256 baselines and semantic article baselines are retained in the test suite, outside the publish directory.
