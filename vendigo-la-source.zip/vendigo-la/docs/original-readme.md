# Vendigo LA website — Netlify static deploy

This is a static, multi-page website. The supplied workspace did not contain an application repository or existing integrations to preserve. All 23 pages are separate HTML files with shared styling in `site.css` and interaction code in `site.js`.

## Netlify deployment

- For manual deploy, drag the **contents of this `outputs/` folder** into Netlify Drop.
- For Git deployment, set the base directory to `outputs`; `netlify.toml` publishes `.` with no build command.
- The website uses root-relative links and should be published at the domain root.
- The logo SVGs, favicon, and school campus photo are local. Other Unsplash photography and Google Fonts need internet access.

## Recent updates

- Added the provided Vendigo mark and wordmark colors to the header and footer, including the reverse mark for the dark footer.
- Made the homepage's secondary “Explore Solutions” action a filled warm-brown button with light text.
- Replaced the Privacy Policy, Cookie Policy and Terms pages with the supplied text. Their copy is preserved as provided.

## Inquiry behavior

The contact form and inquiry chatbot submit directly to Formspree (`https://formspree.io/f/xoejbkbg`). The interface shows a success message only after Formspree accepts the submission, and displays an error if delivery fails. Formspree must be configured to deliver submissions to the intended inbox. WhatsApp continues to open a prefilled message for the visitor to review and send. A hidden honeypot field provides basic spam filtering.

- Updated the Accessibility Statement with the supplied copy and contact details.
- Bundled the school campus photo locally at `assets/schools-campus.jpg` to avoid a broken remote image on the homepage.
- Connected the contact form and chatbot inquiry action to the supplied Formspree endpoint with confirmation and error states.
