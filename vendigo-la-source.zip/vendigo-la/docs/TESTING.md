# Validation results

Validated locally on 16 November 2026. No live deployment was performed.

## Installation and production builds

- `npm install`: succeeded; lockfile created.
- Fresh `npm ci` from the final lockfile: succeeded, 151 installed packages, zero vulnerabilities reported by npm at install time.
- `npm run build`: succeeded, Eleventy 3.1.8. Generated 30 HTML pages plus sitemap and preserved public assets.
- `npm test`: 5 test groups passed, 0 failures.
- The full test suite and its production builds also passed using **Node 22.23.5**, matching the configured Node 22 runtime family. Earlier validation also passed on Node 26.13.0.

Final direct dependencies locked: Eleventy 3.1.8, markdown-it 14.3.3, sanitize-html 2.18.2, image-size 2.1.0, yaml 2.9.1; cheerio 1.0.0 for tests. npm emitted a transitive `whatwg-encoding` deprecation warning from test tooling; it did not block installation or builds.

## Automated evidence

1. All seven original article paths exist. DOM signatures match the original HTML for complete body text, heading levels, paragraph/list/table structure and link attributes. Original H1, deck, SEO title and description match exactly. CTA, header, footer and chatbot signatures match. Existing articles contain no invented publication/update dates.
2. SHA-256 comparisons verify all unchanged original public files, including business pages, assets, stylesheet, JavaScript, robots and headers. The original example template also matches. The original readme is retained privately under docs rather than published.
3. All generated internal page/asset links and fragment targets resolve. Sitemap contains 29 unique canonical URLs, with the seven duplicate entries removed. All seven original cards retain their original order when dates are absent.
4. CMS schema contains all 19 fields, required inputs, Markdown body and correct media input/public paths. Status defaults to Draft. Optional dates explicitly default to empty (Pages CMS otherwise initializes date fields to today).
5. Temporary fixture tests exercise draft creation, publishing, title/excerpt edits, featured and inline images with intrinsic dimensions, newest-first sorting, real dates, unpublishing and stale-file removal. Duplicate slug, path traversal, invalid dates, missing image/alt text, invalid canonical and missing required content are rejected. Build failure for duplicates is verified. Fixtures are removed and original published output is rebuilt in a `finally` block.
6. Raw HTML and unsafe links cannot become active markup. Body H1 and remote image URLs are rejected. Script-closing text in article titles remains text; structured data parses correctly without an injected script. Source content and configuration are absent from public output.

## Browser checks

- Opened generated archive and a migrated article at localhost in a desktop browser.
- Verified the archive hero, cards, original branding and inquiry sidebar; article heading, semantic table, body and preserved shell.
- Opened and closed the existing chatbot successfully.
- Checked article/archive at a mobile viewport, opened mobile navigation, and navigated back to the archive. Observed page width did not exceed the viewport.
- Saved a desktop preview image alongside the delivery archives.

## Not tested or changed externally

GitHub login/repository permissions, native CMS edit/save/delete confirmation behavior, rich-text table round trips, actual uploads through hosted Pages CMS, CMS commits triggering Netlify, DNS/custom-domain/TLS settings, production deploys and real Formspree/chatbot lead delivery require owner account access. They are not claimed as verified. README contains the exact account setup and manual acceptance steps.

Duplicate-slug validation is authoritative during build, not a custom cross-document check inside Pages CMS. Failed deploys preserve the previous live version. Unpublishing is effective publicly only after a valid deployment succeeds. Uploaded draft media is public; draft text is absent from generated output but repository visibility governs access to its source.
