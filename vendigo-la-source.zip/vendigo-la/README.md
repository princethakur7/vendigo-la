# Vendigo LA: Pages CMS blog

The seven existing articles now live in `content/posts/*.md`. Eleventy generates their original URLs, the archive, and a unique sitemap. Existing business HTML pages, `site.css`, `site.js`, logos, robots rules and headers are preserved. There is no local admin screen: the editor is the real hosted [Pages CMS application](https://app.pagescms.org/).

**Status:** implemented and tested locally. GitHub, Pages CMS authorization, Netlify repository linking, production domain verification and live deployment must be completed by the owner. No live deployment or account authorization was performed.

## Run locally

Use Node 22 (also pinned in `.nvmrc` and Netlify).

```sh
npm ci
npm run build
npm test
npm start
```

Open `http://127.0.0.1:8080/blog/`. `npm start` rebuilds and serves only `_site`, binding to localhost. Stop with Ctrl+C. Re-run after edits; this intentionally uses complete clean builds, including during preview, to avoid stale unpublished pages. `npm install` also works; use `npm ci` for reproducible dependency installation from the included lockfile. Netlify installs dependencies before running the build command. Do not set `NODE_ENV=production` or otherwise omit dev dependencies when running the test workflow.

## What was implemented automatically

- Pages CMS collection with a visual Markdown body editor, image uploads and all 19 requested fields.
- All seven complete articles migrated, including the comparison table and all authored links.
- One article template, dynamic cards and article numbering, with the original inquiry CTA and site shell.
- Draft/published filtering and clean output; a valid unpublish removes the old HTML on the next successful deploy.
- SEO fallbacks, canonical URLs, Open Graph, Twitter cards, Article JSON-LD and sitemap generation.
- Build validation, GitHub CI, migration regression tests and owner instructions.

## Connect accounts: owner steps

1. Create a GitHub repository under an account or organization you control. A private repository keeps drafts private. Commit the **contents of this project folder** at the repository root, including `.pages.yml`, the lockfile, content and templates. Exclude `node_modules` and `_site` as specified by `.gitignore`.
2. Give each marketing editor only the repository access they need. Sign in to [https://app.pagescms.org/](https://app.pagescms.org/) with GitHub. Complete the GitHub authorization/installation for this repository, then select the repository and publishing branch, normally `main`. The app reads `.pages.yml` on that branch. No token belongs in HTML or `site.js`.
3. Open **Blog articles**. Confirm that all seven articles and the Media section load. If the repository is missing, check the GitHub app installation's selected repositories and the editor's repository permissions. Owners control installation and collaborator access; remove access there when an editor leaves.
4. In the **existing Netlify site**, connect its continuous deployment settings to that GitHub repository and production branch. A Drop/manual-deploy site must be linked to Git before CMS saves can trigger deployments. If linking the existing site is unavailable, ask the Netlify site owner to connect it rather than creating an accidental second production site.
5. Let Netlify use `netlify.toml`: build command `npm run build`, publish directory `_site`, Node 22, base directory empty when this project is at repository root. Remove conflicting dashboard settings. Do not publish the source root.
6. Verify the production/custom-domain settings and DNS for **vendigola.com**, including HTTPS and the preferred www/apex redirect. The supplied pages already declare `https://vendigola.com`; external probing could not confirm account-level configuration. Preview deploy URLs deliberately do not become canonical URLs. If the production domain must change, update the canonical constant, templates, original static-page metadata, robots sitemap URL and static sitemap URL data as one reviewed change.
7. Deploy and inspect the Netlify build log. Open the homepage, `/blog/`, all seven old article URLs and `/sitemap.xml`. Complete the manual checklist below before calling the hosted workflow verified.

The exact CMS login URL is **https://app.pagescms.org/**. The repository-specific editor route is supplied by Pages CMS after you select your actual repository and branch; no repository name or account was provided, so no such route has been invented.

CMS saves create GitHub changes. Netlify then builds and publishes them. **Content is live only after the deployment succeeds**, not immediately when Save completes. A failed deployment leaves the previous successful version online, including any article you were trying to unpublish. Check deploy status after each publication change.

## Marketing publishing guide

### Create and save a draft

Open Pages CMS → select repository and branch → Blog articles → create a new entry. Fill in title, a unique URL slug, short excerpt, body and status **Draft**. Save. Use lowercase words and hyphens for slugs. New files are named from the slug, e.g. `workplace-snacks.md`. Draft status is required; an absent or invalid status blocks a build rather than accidentally publishing.

Use H2 and H3 for body sections; the title supplies the page's only H1. Use the visual editor for paragraphs, headings, links, lists and images. The existing comparison table uses standard GitHub-flavored Markdown. Use the editor's Source mode when table controls are unavailable. Raw HTML is shown as text, never run as trusted markup.

### Images

Upload JPG, PNG, WebP, GIF or AVIF through the featured-image picker or body editor. Files go into `assets/blog` and public references use `/assets/blog/...`. Add meaningful alt text in the body image dialog and the featured-image alt field. Uploaded raster files are validated and their intrinsic width/height is generated. Inline and card images lazy-load; the article's featured image loads normally. Images scale responsively. Open Graph image falls back to the featured image. Use your own appropriately sized files; this implementation does not add a paid optimizer.

Avoid remote image URLs, SVG uploads or filename characters outside letters, digits, underscores, hyphens, dots and slashes. Upload renaming uses the CMS's safe option. Existing logo SVG files are unchanged and outside the CMS media folder. Media files, including images uploaded for draft articles, are public after deployment; never upload private material. Draft text is excluded from the public output but is visible to anyone who can read the GitHub repository.

### Publish, edit and unpublish

- **Publish:** choose Published, optionally enter a known publication date, Save, then wait for Netlify success. The article appears at `/blog/YOUR-SLUG/`, in the archive and sitemap automatically.
- **Edit:** open an existing article, change content or excerpt/SEO fields, Save, then verify its successful deployment. Keep published slugs unchanged to preserve links.
- **Unpublish:** choose Draft and Save. After a successful deploy, the URL returns 404 and disappears from archive and sitemap. The Markdown file remains editable. Search engines may take time to remove previously indexed results.
- **Delete:** prefer unpublish when content should be retained. Use the CMS native deletion flow and review its confirmation before deleting. Git history remains the recovery mechanism; no custom destructive dashboard exists.
- **Rollback:** in GitHub, revert the mistaken content commit (or restore that file from history), commit to the publishing branch, then wait for a successful Netlify deployment. Restoring a Netlify deploy alone is temporary: make Git match the intended version or the next CMS save can rebuild the mistake.

Publication and update dates are optional. None were verified for the seven migrated articles, so both are blank and omitted from JSON-LD and sitemap timestamps. Do not use file/ZIP modification times as article dates. Dated articles sort newest first; undated original articles retain their original order, followed by new undated articles in slug order. Author defaults to the organization Vendigo LA, without fabricated person names or credentials. SEO fields fall back to title/excerpt, and canonical falls back to the original production domain plus article path. Canonical overrides must match that article's actual production URL. Featured is stored as an editorial flag; it does not override the required newest-first archive order.

## Validation and security

Required fields are enforced in Pages CMS and again during build. Slug syntax is checked in the editor; **cross-file duplicate slugs are rejected at build time**, including duplicates in drafts. Pages CMS has no custom cross-document validator in this project. Slug-based filenames also help avoid creating the same file twice, but deployment validation is the authoritative safeguard. Do not overwrite another entry when choosing its filename.

A failed validation produces a file-specific error in the deploy log. Blank bodies, invalid dates, missing images/alt text, unsafe paths, reserved slugs and duplicate published SEO titles also fail the build. Dates must be YYYY-MM-DD. Optional SEO metadata safely falls back rather than requiring manual duplication. Markdown raw HTML is disabled, rendered output is allowlist-sanitized, and JSON-LD escapes `<`. Content is read as YAML only and cannot execute a JavaScript frontmatter engine. CMS content is not interpreted as a Nunjucks template.

Only explicit public files/directories are copied to `_site`. Configuration, Markdown, test baselines, dependencies and documentation are never published. For a new static business-page directory, deliberately add it to the public allowlist in `eleventy.config.js`. `_headers` and original Formspree actions remain unchanged. No credentials or custom authentication were introduced; authorization is GitHub/Pages CMS's responsibility.

## Troubleshooting

- **Save succeeded but the site is unchanged:** check the selected CMS branch, Netlify's linked repository/production branch, build status and log. Check that the post is Published. Wait for deploy completion, then refresh.
- **Duplicate slug or SEO title:** open the filename named in the error and correct it. Do not change a live slug casually. Old published content stays online until a valid deploy succeeds.
- **Missing image/alt text:** choose an uploaded local raster image and fill in descriptive alt text. Paths must start with `/assets/` and match a real file.
- **Build fails after saving a date:** enter a real YYYY-MM-DD date or leave blank. Updated date cannot precede publication date.
- **npm command fails:** use Node 22, run from the project folder, run `npm ci`, then `npm run build`. Do not edit `_site` to fix content.
- **CMS has no collection:** verify `.pages.yml` is at repository root on the selected branch, then inspect GitHub installation and repository access.
- **Forms fail:** confirm the existing Formspree project is active and the production domain is permitted. No endpoint change was made. Real delivery requires an owner-approved test submission.
- **CI branch protection prevents CMS saves:** configure an appropriate CMS branch and review/merge workflow, or use an authorized content publishing branch Netlify builds. Do not grant broader permissions simply to bypass protection.

## Manual hosted verification (not executed locally)

1. Log in as an authorized editor. Confirm an unauthorized account cannot edit the repository. Verify GitHub installation scope.
2. Open each migrated article in the visual editor, including the comparison table. Save an unchanged article on a test branch; confirm its body, links and table survive a CMS round trip without changes. Review the Git diff and deploy preview.
3. Create a Draft article, save, and inspect the GitHub commit. Confirm no public URL, archive card or sitemap entry after successful preview deployment.
4. Edit title/excerpt, add featured and inline images with alt text, set real dates/SEO fields, save as Published and verify deployed HTML, paths, image dimensions, metadata and newest-first ordering.
5. Change back to Draft, wait for deployment success and verify the former URL is 404. Check archive and sitemap again.
6. On a test branch, attempt a second file with the same slug. Confirm the build fails with a duplicate-slug error; correct it before merging. Test deleting a disposable entry with the CMS native confirmation and restoring it from Git history.
7. With owner approval, submit one real Formspree inquiry and complete the chatbot inquiry flow; verify receipt. Local testing preserved their markup and JS and verified chatbot opening/mobile menu, but did not transmit lead submissions.
8. Verify live custom-domain/DNS/TLS settings and all seven article URLs after the production deploy.

## Structure and dependencies

```text
index.html, about/, solutions/, industries/, ...  original business pages
assets/                                         original public assets + blog uploads
content/posts/*.md                              seven editable articles
src/blog/article.njk, archive.njk                generated article/archive templates
src/_includes/                                  existing header/footer/inquiry + SEO head
src/_data/                                      published posts + static sitemap URLs
src/sitemap.njk                                 generated sitemap
lib/posts.cjs, legacy-order.json                 validated Markdown rendering + original order
.pages.yml                                      hosted Pages CMS configuration
scripts/                                        clean build and local static preview
tests/                                         migration baseline + workflow regression checks
.github/workflows/validate.yml                   GitHub CI
_site/                                          disposable generated production output
```

Runtime dependencies: Eleventy, markdown-it, sanitize-html, image-size and yaml. Test dependency: cheerio. Exact versions are locked in `package-lock.json`; nothing new loads in the visitor's browser. See [audit and change manifest](docs/AUDIT.md) and [test results](docs/TESTING.md).

Official configuration references: [Pages CMS collections](https://pagescms.org/docs/configuration/content/), [fields](https://pagescms.org/docs/configuration/content/fields/), [rich text](https://pagescms.org/docs/configuration/fields/rich-text/), [media](https://pagescms.org/docs/configuration/media/), [filenames](https://pagescms.org/docs/configuration/content/filename/), and [Eleventy passthrough copy](https://www.11ty.dev/docs/copy/).
